void evolve(int Nx, int Ny, double in[][Ny], double out[][Ny], double D, double dt);
